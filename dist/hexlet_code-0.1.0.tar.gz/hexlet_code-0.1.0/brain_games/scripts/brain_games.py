#!/usr/bin/env python3


def welcome():
    print(f"Welcome to the Brain Games!")

def main():
    welcome()

if __name__ == '__main':
    main()
