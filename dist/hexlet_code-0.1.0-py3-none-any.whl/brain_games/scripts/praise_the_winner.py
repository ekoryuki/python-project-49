def praise_the_winner(right_answers, name):
    if right_answers == 3:
        print(f'Congratulations, {name}!')
